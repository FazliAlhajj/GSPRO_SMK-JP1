<?php

session_start();

unset($_SESSION['username']);
session_destroy();
echo "<script type='text/java script'>
    alert(Anda berhasil logout');
    window.location = 'index.php'
</script>";

?>