<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <div class="sidebar">
        <a href="index.php">Dashboard</a>
        <a href="user.php">Data User</a>
        <a href="produk.php">Data Produk</a>
        <a href="transaksi.php">Data Transaksi</a>
        <a href="verif_transaksi.php">Verifikasi Transaksi</a>
        <a href="../logout.php">Logout</a>
    </div>
</body>
</html>